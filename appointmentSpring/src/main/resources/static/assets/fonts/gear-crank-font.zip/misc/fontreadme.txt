Thank you for downloading one of Andrew Babb's (Buzzbum's) fonts. 
I hope you enjoy using this typeface. This is a FREEWARE font that you can use
for anything commercial or private without charge. 

However, one note: If you use one of these fonts for a commercial use, please send me an example of product/service/advertisement. I like looking at what other people do with my fonts.

Thanks.

-Andrew (Primelord2@aol.com)
http://members.tripod.com/~buzzbum